<?php
$server = "localhost:3316";
$user = "root";
$pass = "";
$db = "db_reportes_pdf";

$conn = mysqli_connect("$server","$user","$pass","$db");

if(!$conn){
    echo "Error de conexion";
}
?>