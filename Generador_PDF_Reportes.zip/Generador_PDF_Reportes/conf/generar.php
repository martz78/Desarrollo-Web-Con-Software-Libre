<?php
require("../dompdf/autoload.inc.php");
include("../conf/conf.php");

$archivo = "DWSL" . date('Ymd_His') . ".pdf";
$opcion = $_POST['opcion'];

// reference the Dompdf namespace
use Dompdf\Dompdf;
if($opcion == 1){
    $query = "SELECT * FROM tbl_invesproduct";
    $exec = mysqli_query($conn, $query);

    $html = '<table border = "1" cellspacing="0" align="center">
<thead>
<tr>
    <th>Id</th>
    <th>Producto</th>
    <th>Proveedor</th>
    <th>Existencia</th>
    <th>Bodega</th>
    <th>Precio</th>
    <th>Fecha vencimiento</th>
    <th>Fecha introduccion</th>
</tr>
</thead>
';

while($row = $exec->fetch_assoc()) {
    $html .= '
    <tr>
                        <td>'. $row['id']. '</td>
                        <td>'. $row['producto'] .'</td>
                        <td>'. $row['proveedor'].'</td>
                        <td>'. $row['existencias'] .'</td>
                        <td>'. $row['bodegas'] .'</td>
                        <td>'. $row['precio'] .'</td>
                        <td>'. $row['vencimiento'] .'</td>
                        <td>'. $row['introduccion'] .'</td>
                        </tr>
    ';
}
    $html .= '</table>';
}else if($opcion == 2){
    $nameProducto = $_POST['nameProducto'];
    
    $query = "SELECT producto, proveedor, precio FROM tbl_invesproduct WHERE producto LIKE '%$nameProducto%'";
    $exec = mysqli_query($conn, $query);

    $html = '<table border = "1" cellspacing="0" align="center">
<thead>
<tr>
    <th hidden>Producto</th>
    <th>Proveedor</th>
    <th>Precio</th>
</tr>
</thead>
';

while($row = $exec->fetch_assoc()) {
    $html .= '
    <tr>
                        <td hidden>'. $row['producto'] .'</td>
                        <td>'. $row['proveedor'].'</td>
                        <td>'. $row['precio'] .'</td>
                        </tr>
    ';
}
    $html .= '</table>';
}else if($opcion == 3){
    $nameProveedor = $_POST['nameProveedor'];
    
    $query = "SELECT producto, proveedor, precio FROM tbl_invesproduct WHERE producto LIKE '%$nameProveedor%'";
    $exec = mysqli_query($conn, $query);

    $html = '<table border = "1" cellspacing="0" align="center">
<thead>
<tr>
    <th>Proveedor</th>
    <th>Existencia</th>
    <th>Bodega</th>
    <th>Fecha introduccion</th>
    <th>Fecha vencimiento</th>
</tr>
</thead>
';

while($row = $exec->fetch_assoc()) {
    $html .= '
    <tr>
                        <td hidden>'. $row['proveedor'] .'</td>
                        <td>'. $row['existencias'].'</td>
                        <td>'. $row['bodegas'] .'</td>
                        <td>'. $row['introduccion'] .'</td>
                        <td>'. $row['vencimiento'] .'</td>
                        </tr>
    ';
}
    $html .= '</table>';
}else if($opcion == 4){
    $bodega = $_POST['bodega'];
    
    $query = "SELECT bodegas, producto FROM tbl_invesproduct WHERE bodegas = '$bodega' GROUP BY producto;";
    $exec = mysqli_query($conn, $query);

    $html = '<table border = "1" cellspacing="0" align="center" text="center">
<thead>
<tr>
    <th>Bodega</th>
    <th>Producto</th>
</tr>
</thead>
';

while($row = $exec->fetch_assoc()) {
    $html .= '
    <tr>
        <td>'. $row['bodegas'] .'</td>
        <td>'. $row['producto'] .'</td>
    </tr>
    ';
}
    $html .= '</table>';
}
// instantiate and use the dompdf class
$dompdf = new Dompdf();
$dompdf->loadHtml($html);

// (Optional) Setup the paper size and orientation
$dompdf->setPaper('A4', 'landscape');

// Render the HTML as PDF
$dompdf->render();

// Output the generated PDF to Browser
$dompdf->stream($archivo);
