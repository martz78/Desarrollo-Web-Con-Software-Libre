<?php
include("../conf/conf.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css" integrity="sha384-xOolHFLEh07PJGoPkLv1IbcEPTNtaed2xpHsD9ESMhqIYd0nLMwNLD69Npy4HI+N" crossorigin="anonymous">
    <title>Document</title>
</head>
<body style="background-color: #343A40;">
    <div class="container p-4">
        <div class="row">
            <div class="col text-left">
                <h1 class="text-light">Reporte por producto</h1>
            </div>
            <div class="col-6 text-left">
            <form action="../conf/generar.php" method="post">
                    <input type="hidden" value="2" name="opcion">
                    <input type="submit" class="btn btn-success" value="Generar Reporte"></input>
                    <br><br>
                    <input type="text" placeholder="Ingrese nombre de un producto" name="nameProducto" id="nameProducto" style="width: 100%;">
                </form>
            </div>
            <div class="col text-right">
                <a href="index.php" class="btn btn-info">↩️Regresar</a>
            </div>
        </div>
        <br><br>
        <div id="resultado">
            <table class="table table-stripped table-bordered table-hover table-dark">
                <thead>
                    <tr>
                        <th>Producto</th>
                        <th>Proveedor</th>
                        <th>Precio</th>
                    </tr>
                </thead>
                <tbody id="tabla-resultados">
                </tbody>
            </table>
        </div>
    </div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js" integrity="sha512-v2CJ7UaYy4JwqLDIrZUI/4hqeoQieOmAZNXBeQyjo21dadnwR+8ZaIJVT8EE2iyI61OV8e6M8PP2/4hpQINQ/g==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>

<script>
        $(document).ready(function() {
            $("#nameProducto").keyup(function() {
                var texto = $(this).val();

                if (texto.trim() === texto && texto != "") {

                    $.ajax({
                        url: "procesar1.php",
                        method: "POST",
                        data: {
                            query: texto
                        },
                        success: function(data) {
                            $("#tabla-resultados").html(data);
                        }
                    });
                } else {
                    $("#tabla-resultados").html("");
                }
            });
        });
    </script>
</body>
</html>