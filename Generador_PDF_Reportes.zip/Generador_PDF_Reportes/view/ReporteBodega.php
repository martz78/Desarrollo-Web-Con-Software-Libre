<?php
include("../conf/conf.php");
$query = "SELECT bodegas, COUNT(DISTINCT producto) AS cantidad_productos FROM tbl_invesproduct GROUP BY bodegas";
$exec = mysqli_query($conn, $query);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css" integrity="sha384-xOolHFLEh07PJGoPkLv1IbcEPTNtaed2xpHsD9ESMhqIYd0nLMwNLD69Npy4HI+N" crossorigin="anonymous">
    <title>Document</title>
</head>
<body style="background-color: #343A40;">
    <div class="container p-4">
        <div class="row">
            <div class="col text-left">
                <h1 class="text-light">Reporte por bodega</h1>
            </div>
            <div class="col-8 text-left">
            <form action="../conf/generar.php" method="post">
                    <input type="hidden" value="4" name="opcion">
                    <input type="submit" class="btn btn-success" value="Generar Reporte"></input><br>
                    <label for="" class="text-white">Ingrese una bodega para generar reporte de los productos dentro de esta</label><br>

                    <input type="number" name="bodega" min="1" max="5" step="1" style="width: 160px;">
                    <br><br>
                </form>
            </div>
            <div class="col text-right">
                <a href="index.php" class="btn btn-info">↩️Regresar</a>
            </div>
        </div>
        <br><br>
        <div id="resultado">
            <table class="table table-stripped table-bordered table-hover table-dark text-center">
                <thead>
                    <tr>
                        <th>Bodegas</th>
                        <th>Cantida de productos</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    while ($row = mysqli_fetch_assoc($exec)){
                    ?>
                    <tr>
                        <td><?= $row['bodegas'] ?></td>
                        <td><?= $row['cantidad_productos'] ?></td>
                    </tr>
                    <?php
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>