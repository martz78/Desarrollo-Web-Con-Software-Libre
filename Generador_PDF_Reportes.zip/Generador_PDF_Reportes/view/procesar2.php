<?php
include("../conf/conf.php");

if (isset($_POST['query'])) {

    if ($conn->connect_error) {
        die("Conexión fallida: " . $conn->connect_error);
    }

    $query = $conn->real_escape_string(trim($_POST["query"]));

    $sql = "SELECT  proveedor, existencias, bodegas, introduccion, vencimiento FROM tbl_invesproduct WHERE proveedor LIKE '%$query%'";

    
    $result = $conn->query($sql);
    
    if ($result->num_rows > 0) {
        while ($row = mysqli_fetch_array($result)) {
            echo "<tr>
                    <td> $row[0] </td>
                    <td> $row[1] </td>
                    <td> $row[2] </td>
                    <td> $row[3] </td>
                    <td> $row[4] </td>
            </tr>";
        }
    } else {
        echo "<tr><td>No se encontraron resultados</td></tr>";
    }
}
?>