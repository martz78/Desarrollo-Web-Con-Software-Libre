<?php
include("../conf/conf.php");

if (isset($_POST['query'])) {

    if ($conn->connect_error) {
        die("Conexión fallida: " . $conn->connect_error);
    }

    $query = $conn->real_escape_string(trim($_POST["query"]));

    $sql = "SELECT producto, proveedor, precio FROM tbl_invesproduct WHERE producto LIKE '%$query%'";

    
    $result = $conn->query($sql);
    
    if ($result->num_rows > 0) {
        while ($row = mysqli_fetch_array($result)) {
            echo "<tr>
                    <td> $row[0] </td>
                    <td> $row[1] </td>
                    <td> $row[2] </td>
            </tr>";
        }
    } else {
        echo "<tr><td>No se encontraron resultados</td></tr>";
    }
}
?>