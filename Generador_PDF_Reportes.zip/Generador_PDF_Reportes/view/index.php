<?php
include("../conf/conf.php");

// Establecer el número de registros por página y obtener la página actual
$records_per_page = 20;
$page = isset($_GET['page']) ? $_GET['page'] : 1;
$offset = ($page - 1) * $records_per_page;

$query = "SELECT * FROM tbl_invesproduct LIMIT $offset, $records_per_page";
$exec = mysqli_query($conn, $query);

// Obtener el total de registros para calcular el número total de páginas
$total_records_query = "SELECT COUNT(*) AS total FROM tbl_invesproduct";
$total_records_result = mysqli_query($conn, $total_records_query);
$total_records = mysqli_fetch_assoc($total_records_result)['total'];
$total_pages = ceil($total_records / $records_per_page);
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css" integrity="sha384-xOolHFLEh07PJGoPkLv1IbcEPTNtaed2xpHsD9ESMhqIYd0nLMwNLD69Npy4HI+N" crossorigin="anonymous">
    <title>Generador de reportes</title>
</head>

<body style="background-color: #343A40;">
    <div class="container">
        <div class="row p-4">
            <div class="col-4 text-left">
                <h1 class="text-white">Vista principal</h1>
            </div>
            <div class="col-2 text-left">
                <a class="btn btn-primary" href="ReporteProducto.php">Reporte Producto</a>
            </div>
            <div class="col-2 text-left">
                <a class="btn btn-danger" href="ReporteProveedor.php">Reporte Proveedor</a>
            </div>
            <div class="col-2 text-left">
                <a class="btn btn-info" href="ReporteBodega.php">Reporte por bodega</a>
            </div>
            <div class="col-2 text-right">
                <form action="../conf/generar.php" method="post">
                    <input type="hidden" value="1" name="opcion">
                    <input type="submit" class="btn btn-success" value="Reporte General"></input>
                </form>
            </div>
        </div>
        <div class="col">
            <table class="table table-stripped table-bordered table-hover table-dark">
                <thead>
                    <tr>
                        <th hidden>Id</th>
                        <th>Producto</th>
                        <th>Proveedor</th>
                        <th>Existencia</th>
                        <th>Bodega</th>
                        <th>Precio</th>
                        <th>Fecha vencimiento</th>
                        <th>Fecha introduccion</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    while( $row = mysqli_fetch_assoc($exec) ){
                        ?>
                        <tr>
                        <td hidden><?= $row['id'] ?></td>
                        <td><?= $row['producto'] ?></td>
                        <td><?= $row['proveedor'] ?></td>
                        <td><?= $row['existencias'] ?></td>
                        <td><?= $row['bodegas'] ?></td>
                        <td><?= $row['precio'] ?></td>
                        <td><?= $row['vencimiento'] ?></td>
                        <td><?= $row['introduccion'] ?></td>
                        </tr>
                        <?php
                    }
                    ?>
                </tbody>
            </table>
            <!-- Agregar la paginación -->
            <nav aria-label="Page navigation">
                <ul class="pagination justify-content-center">
                    <?php for ($i = 1; $i <= 10; $i++) { ?>
                        <li class="page-item <?php if ($i == $page) echo 'active'; ?>">
                            <a class="page-link" href="?page=<?= $i ?>"><?= $i ?></a>
                        </li>
                    <?php } ?>
                </ul>
            </nav>
        </div>
    </div>
</body>

</html>